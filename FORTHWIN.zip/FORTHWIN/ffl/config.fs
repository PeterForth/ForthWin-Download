\ ==============================================================================
\
\                  config - the config in the ffl
\
\             Copyright (C) 2005-2007  Dick van Oudheusden
\                    Copyright (C) 2008 ygrek
\  
\  
\
 


REQUIRE [IF]      lib/include/tools.f

S" ffl.version" FORTH-WORDLIST SEARCH-WORDLIST 0= [IF]

REQUIRE ANSI-FILE lib/include/ansi-file.f
REQUIRE F.        lib/include/float2.f
REQUIRE .R        lib/include/core-ext.f
REQUIRE /STRING   lib/include/string.f
REQUIRE DEFER     lib/include/defer.f
REQUIRE M*/       lib/include/double.f
REQUIRE CASE      lib/ext/case.f
REQUIRE TIME&DATE lib/include/facil.f

\ REQUIRE COMPARE-U ~ac/lib/string/compare-u.f

[UNDEFINED] CHAR-UPPERCASE [IF]

: CHAR-UPPERCASE

  DUP [CHAR] a [CHAR] z 1+ WITHIN IF 32 - EXIT THEN
  DUP [CHAR] а [CHAR] я 1+ WITHIN IF 32 - THEN
;
[THEN]

REQUIRE CASE-INS  lib/ext/caseins.f

CASE-INS ON

 

000900 constant ffl.version


 
  
variable ffl.endian  
 1 ffl.endian !


 

create end-of-line    
EOLN S",  

s" ADDRESS-UNIT-BITS" 
environment? 

0= [IF] 8 [THEN] 
  constant #bits/byte    
  
#bits/byte 1 chars *
  constant #bits/char    
  
#bits/byte cell *
  constant #bits/cell    

ffl.endian c@ 0=             
  constant bigendian?    


( Extension words )

[UNDEFINED] ms@ [IF]

 \ assume windows
 
[UNDEFINED] GetTickCount [IF]

 WINAPI: GetTickCount KERNEL32.DLL
 
[THEN]

: ms@ ( -- u ) GetTickCount  ;

[THEN]


s" MAX-U" environment? 0= [IF] -1 [THEN] constant max-ms@    


\ Command line is a single string in SPF/Win32

[DEFINED] ARGC [IF]   \ available in SPF/Linux

: #args           
  ARGC 1-
;

: arg@              
  1+ CELLS ARGV + @ ASCIIZ>
;
[THEN]


: include PARSE-NAME ANSI-FILE::>ZFILENAME INCLUDED ;


: file-status       
  FILE-EXIST 0= 0 swap
;


: MS PAUSE ;

: BIN ;

: UD. D. ;

MODULE: inner

[DEFINED] COMPARE-U [IF]

: COMPARE-U COMPARE-U ;
[ELSE]

: UPPERCASE  
  OVER + SWAP ?DO
    I C@ CHAR-UPPERCASE I C!
  LOOP ;

: COMPARE-CHAR-U  
  2DUP = IF 2DROP 0 EXIT THEN
  CHAR-UPPERCASE SWAP CHAR-UPPERCASE -
  DUP 0= IF EXIT THEN
  0< IF 1 EXIT THEN -1
   
  
;

: COMPARE-U  
  ROT 2DUP - >R UMIN
  0 ?DO 2DUP
  C@ SWAP C@ SWAP
  COMPARE-CHAR-U DUP IF NIP NIP UNLOOP RDROP EXIT THEN DROP
  SWAP CHAR+ SWAP CHAR+
  LOOP 2DROP R>
  DUP 0= IF EXIT THEN
  0< IF 1 EXIT THEN -1
   
;
[THEN]
;MODULE


: icompare   
 
  inner::COMPARE-U
;

 
8    CONSTANT float

TRUE CONSTANT FLOATING-EXT
6    CONSTANT FLOATING-STACK

[DEFINED] float [IF]

 

0E+0 fconstant 0e+0   
1E+0 fconstant 1e+0   
2E+0 fconstant 2e+0   


 

: f>           
  fswap f<
;

[THEN]

 

include ffl/tlb.fs


 

variable exp-next  -2050 exp-next !

: exception      
  2drop
  exp-next @ 
  exp-next 1-!
;

s" Index out of range" exception constant exp-index-out-of-range 
 
s" Invalid state"      exception constant exp-invalid-state     
\  ( -- n = Invalid state exception number )
s" No data available"  exception constant exp-no-data     
\        ( -- n = No data available exception number )
s" Invalid parameters" exception constant exp-invalid-parameters
\  ( -- n = Invalid parameters on stack )
s" Wrong file type"    exception constant exp-wrong-file-type   
\  ( -- n = Wrong file type )
s" Wrong file version" exception constant exp-wrong-file-version 
\ ( -- n = Wrong file version )
s" Wrong file data"    exception constant exp-wrong-file-data    
\ ( -- n = Wrong file data )
s" Wrong checksum"     exception constant exp-wrong-checksum   
\   ( -- n = Wrong checksum )
s" Wrong length"       exception constant exp-wrong-length    
\    ( -- n = Wrong length )
s" Invalid data"       exception constant exp-invalid-data   
\     ( -- n = Invalid data exception number )

[ELSE]
  drop
[THEN]

\ ================== 

