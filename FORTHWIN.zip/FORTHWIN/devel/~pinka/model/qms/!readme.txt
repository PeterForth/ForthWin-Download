QMS -- Queue Management System
