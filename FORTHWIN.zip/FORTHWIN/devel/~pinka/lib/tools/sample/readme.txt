\ 19.Aug.2003 Tue 15:37

thanks to PhiHo ( "PhiHo Hoang" <phiho.hoang@rogers.com> )
for testing exe2dll.f  and indicating a some bugs

