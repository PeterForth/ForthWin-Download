Yakimov D. A. Small Libraries for SP-FORTH 3.75

cgi.f CGI Developer Library - CGI on html with interspersed fort
link.f - Convenient organization of static lists
doer.f - Great in Depth Thought by Brody
clparam.f - Convenient command line parsing
sbnf.f - Simple but sometimes indispensable BNF style parser
buffile - A simple library for buffered file access.
hash.f - A nice hash function
console.f - Different words for working with the console

temps.f - Temps Cherezova, rewritten in assembly language + added
                construction !! ... !! - analogue || ... || ((...))

common.f - Various useful words
crc.f - Checksum calculation crc32 - array or file
cs.f - Working with strings
dvar.f - Working with double-length variables (64 bits)
inline.f - Really increase the speed of your FORT program.
                inline insert some words
                
rnd.f - Good random numbers
scramble.f Shuffle the string
code.f - Sometimes you need to write one word in codes, and assembler
                I do not want to connect - very large. This helps either.
                in such situation.
                
dssp.f - DSSP style control structures            
