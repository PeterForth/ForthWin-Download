
1. compile server.f
2. run server.exe /RegServer
3. execute test.vbs